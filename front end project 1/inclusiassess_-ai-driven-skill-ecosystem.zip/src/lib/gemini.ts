import { GoogleGenAI, Type } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;
const genAI = new GoogleGenAI({ apiKey: apiKey || "" });

export async function getPersonalizedFeedback(score: number, total: number, answers: any[]) {
  const model = "gemini-3-flash-preview";
  const prompt = `Analyze the following assessment results for a Java developer:
  Score: ${score}/${total}
  Answers: ${JSON.stringify(answers)}
  
  Provide a personalized feedback report including:
  1. Strengths identified.
  2. Specific skill gaps (e.g., multithreading, Spring Boot, security).
  3. A recommended learning path for the next 4 weeks.
  4. Encouraging remarks for inclusivity.
  
  Format the response as Markdown.`;

  try {
    const response = await genAI.models.generateContent({
      model,
      contents: prompt,
    });
    return response.text || "Feedback currently unavailable.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error generating AI feedback. Please try again later.";
  }
}

export async function getAdaptiveQuestion(previousPerformance: string) {
  const model = "gemini-3-flash-preview";
  const prompt = `Generate a single multiple-choice question for a Java skill assessment.
  Context: The learner's previous performance was "${previousPerformance}".
  Adjust the difficulty accordingly (Easy, Medium, Hard).
  
  Return the response in JSON format with:
  - question: string
  - options: string[] (exactly 4)
  - correctAnswer: number (index 0-3)
  - difficulty: string
  - explanation: string`;

  try {
    const response = await genAI.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            question: { type: Type.STRING },
            options: { type: Type.ARRAY, items: { type: Type.STRING } },
            correctAnswer: { type: Type.INTEGER },
            difficulty: { type: Type.STRING },
            explanation: { type: Type.STRING },
          },
          required: ["question", "options", "correctAnswer", "difficulty", "explanation"],
        },
      },
    });
    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Gemini Error:", error);
    return null;
  }
}
