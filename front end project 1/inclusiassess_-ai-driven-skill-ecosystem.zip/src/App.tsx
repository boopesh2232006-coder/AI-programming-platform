import React, { useState, useEffect } from 'react';
import { 
  Brain, 
  Accessibility, 
  ShieldCheck, 
  Code, 
  ChevronRight, 
  Volume2, 
  Mic, 
  Settings,
  CheckCircle2,
  XCircle,
  Loader2,
  RefreshCw,
  BookOpen,
  Trophy,
  User,
  LayoutDashboard
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { getPersonalizedFeedback, getAdaptiveQuestion } from './lib/gemini';
import { cn } from './lib/utils';

// --- Types ---
interface Question {
  question: string;
  options: string[];
  correctAnswer: number;
  difficulty: string;
  explanation: string;
}

// --- Components ---

const Header = () => (
  <header className="border-b border-gray-200 bg-white/80 backdrop-blur-md sticky top-0 z-50">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <div className="bg-indigo-600 p-2 rounded-lg">
          <Brain className="text-white w-6 h-6" />
        </div>
        <span className="text-xl font-bold text-gray-900 tracking-tight">InclusiAssess</span>
      </div>
      <nav className="hidden md:flex items-center gap-8">
        <a href="#" className="text-sm font-medium text-indigo-600">Dashboard</a>
        <a href="#" className="text-sm font-medium text-gray-500 hover:text-gray-900">Skill Ecosystem</a>
        <a href="#" className="text-sm font-medium text-gray-500 hover:text-gray-900">Accessibility</a>
      </nav>
      <div className="flex items-center gap-4">
        <button className="p-2 text-gray-400 hover:text-gray-600 transition-colors">
          <Settings className="w-5 h-5" />
        </button>
        <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center">
          <User className="w-5 h-5 text-indigo-600" />
        </div>
      </div>
    </div>
  </header>
);

const FeatureCard = ({ icon: Icon, title, description, color }: any) => (
  <motion.div 
    whileHover={{ y: -5 }}
    className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all"
  >
    <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center mb-4", color)}>
      <Icon className="w-6 h-6 text-white" />
    </div>
    <h3 className="text-lg font-semibold text-gray-900 mb-2">{title}</h3>
    <p className="text-gray-500 text-sm leading-relaxed">{description}</p>
  </motion.div>
);

const AdaptiveQuiz = ({ onComplete }: { onComplete: (score: number, total: number, answers: any[]) => void }) => {
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [loading, setLoading] = useState(true);
  const [questionCount, setQuestionCount] = useState(0);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState<any[]>([]);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [performanceHistory, setPerformanceHistory] = useState<string>("Initial assessment");

  const TOTAL_QUESTIONS = 5;

  const fetchNextQuestion = async () => {
    setLoading(true);
    setSelectedOption(null);
    setShowExplanation(false);
    const nextQ = await getAdaptiveQuestion(performanceHistory);
    if (nextQ) {
      setCurrentQuestion(nextQ);
      setQuestionCount(prev => prev + 1);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchNextQuestion();
  }, []);

  const handleOptionSelect = (index: number) => {
    if (selectedOption !== null) return;
    setSelectedOption(index);
    setShowExplanation(true);
    
    const isCorrect = index === currentQuestion?.correctAnswer;
    if (isCorrect) setScore(prev => prev + 1);
    
    const newAnswer = {
      question: currentQuestion?.question,
      selected: currentQuestion?.options[index],
      correct: currentQuestion?.options[currentQuestion.correctAnswer],
      isCorrect,
      difficulty: currentQuestion?.difficulty
    };
    
    setAnswers(prev => [...prev, newAnswer]);
    setPerformanceHistory(prev => `${prev}. Last difficulty: ${currentQuestion?.difficulty}, Result: ${isCorrect ? 'Correct' : 'Incorrect'}`);
  };

  const handleNext = () => {
    if (questionCount >= TOTAL_QUESTIONS) {
      onComplete(score, TOTAL_QUESTIONS, answers);
    } else {
      fetchNextQuestion();
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <Loader2 className="w-12 h-12 text-indigo-600 animate-spin mb-4" />
        <p className="text-gray-500 font-medium">AI is adapting to your level...</p>
      </div>
    );
  }

  if (!currentQuestion) return null;

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-8 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-xs font-bold uppercase tracking-wider">
            {currentQuestion.difficulty}
          </span>
          <span className="text-sm text-gray-400">Question {questionCount} of {TOTAL_QUESTIONS}</span>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={() => {
              const utterance = new SpeechSynthesisUtterance(currentQuestion.question);
              window.speechSynthesis.speak(utterance);
            }}
            className="p-2 text-gray-400 hover:text-indigo-600 transition-colors" 
            title="Read Aloud"
          >
            <Volume2 className="w-5 h-5" />
          </button>
          <button className="p-2 text-gray-400 hover:text-indigo-600 transition-colors" title="Voice Input">
            <Mic className="w-5 h-5" />
          </button>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        key={questionCount}
      >
        <h2 className="text-2xl font-bold text-gray-900 mb-8 leading-tight">
          {currentQuestion.question}
        </h2>

        <div className="space-y-3">
          {currentQuestion.options.map((option, index) => {
            const isSelected = selectedOption === index;
            const isCorrect = index === currentQuestion.correctAnswer;
            const showCorrect = showExplanation && isCorrect;
            const showWrong = showExplanation && isSelected && !isCorrect;

            return (
              <button
                key={index}
                onClick={() => handleOptionSelect(index)}
                disabled={selectedOption !== null}
                className={cn(
                  "w-full p-4 text-left rounded-xl border-2 transition-all flex items-center justify-between group",
                  isSelected ? "border-indigo-600 bg-indigo-50" : "border-gray-100 hover:border-indigo-200 hover:bg-gray-50",
                  showCorrect && "border-emerald-500 bg-emerald-50",
                  showWrong && "border-rose-500 bg-rose-50"
                )}
              >
                <span className={cn(
                  "font-medium",
                  isSelected ? "text-indigo-900" : "text-gray-700",
                  showCorrect && "text-emerald-900",
                  showWrong && "text-rose-900"
                )}>
                  {option}
                </span>
                {showCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-500" />}
                {showWrong && <XCircle className="w-5 h-5 text-rose-500" />}
              </button>
            );
          })}
        </div>

        <AnimatePresence>
          {showExplanation && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="mt-8 p-6 bg-gray-50 rounded-2xl border border-gray-100"
            >
              <h4 className="font-bold text-gray-900 mb-2">Explanation</h4>
              <p className="text-gray-600 text-sm leading-relaxed">
                {currentQuestion.explanation}
              </p>
              <button
                onClick={handleNext}
                className="mt-6 w-full bg-indigo-600 text-white py-3 rounded-xl font-bold hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
              >
                {questionCount >= TOTAL_QUESTIONS ? 'Finish Assessment' : 'Next Question'}
                <ChevronRight className="w-5 h-5" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};

const ResultsView = ({ score, total, answers }: any) => {
  const [feedback, setFeedback] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const generateFeedback = async () => {
      const result = await getPersonalizedFeedback(score, total, answers);
      setFeedback(result);
      setLoading(false);
    };
    generateFeedback();
  }, []);

  return (
    <div className="max-w-4xl mx-auto py-12 px-4">
      <div className="text-center mb-12">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-indigo-100 rounded-full mb-6">
          <Trophy className="w-10 h-10 text-indigo-600" />
        </div>
        <h1 className="text-4xl font-extrabold text-gray-900 mb-4 tracking-tight">Assessment Complete!</h1>
        <p className="text-gray-500 text-lg">You scored <span className="text-indigo-600 font-bold">{score}</span> out of {total}</p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-8">
          <section className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <Brain className="w-6 h-6 text-indigo-600" />
              <h2 className="text-xl font-bold text-gray-900">AI-Driven Skill Analysis</h2>
            </div>
            {loading ? (
              <div className="flex items-center gap-3 text-gray-400">
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span>Generating your personalized skill ecosystem report...</span>
              </div>
            ) : (
              <div className="prose prose-indigo max-w-none text-gray-600">
                <ReactMarkdown>{feedback || ''}</ReactMarkdown>
              </div>
            )}
          </section>

          <section className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <CheckCircle2 className="w-6 h-6 text-emerald-500" />
              <h2 className="text-xl font-bold text-gray-900">Question Breakdown</h2>
            </div>
            <div className="space-y-4">
              {answers.map((ans: any, i: number) => (
                <div key={i} className="p-4 rounded-xl bg-gray-50 border border-gray-100">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-sm font-bold text-gray-900 mb-1">{ans.question}</p>
                      <p className="text-xs text-gray-500">Difficulty: {ans.difficulty}</p>
                    </div>
                    {ans.isCorrect ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                    ) : (
                      <XCircle className="w-5 h-5 text-rose-500 shrink-0" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        <div className="space-y-6">
          <div className="bg-indigo-600 p-6 rounded-3xl text-white">
            <h3 className="text-lg font-bold mb-4">Next Steps</h3>
            <ul className="space-y-4 text-sm text-indigo-100">
              <li className="flex items-start gap-3">
                <BookOpen className="w-5 h-5 shrink-0" />
                <span>Review Java Multithreading basics</span>
              </li>
              <li className="flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 shrink-0" />
                <span>Implement Spring Security in your next project</span>
              </li>
              <li className="flex items-start gap-3">
                <Code className="w-5 h-5 shrink-0" />
                <span>Practice 5 medium-level LeetCode problems</span>
              </li>
            </ul>
            <button className="mt-8 w-full bg-white text-indigo-600 py-3 rounded-xl font-bold hover:bg-indigo-50 transition-colors">
              Start Learning Path
            </button>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Accessibility Stats</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500">TTS Usage</span>
                <span className="font-bold text-gray-900">12%</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500">Voice Input</span>
                <span className="font-bold text-gray-900">0%</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500">Language</span>
                <span className="font-bold text-gray-900">English</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const [view, setView] = useState<'home' | 'quiz' | 'results'>('home');
  const [results, setResults] = useState<{ score: number; total: number; answers: any[] } | null>(null);

  const startAssessment = () => setView('quiz');
  const handleComplete = (score: number, total: number, answers: any[]) => {
    setResults({ score, total, answers });
    setView('results');
  };

  return (
    <div className="min-h-screen bg-[#fafafa] font-sans text-gray-900">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {view === 'home' && (
          <div className="space-y-16">
            {/* Hero Section */}
            <div className="text-center max-w-3xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-50 text-indigo-700 text-sm font-bold mb-8"
              >
                <Brain className="w-4 h-4" />
                AI-Driven Inclusive Assessment
              </motion.div>
              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="text-5xl md:text-6xl font-extrabold text-gray-900 mb-6 tracking-tight leading-tight"
              >
                Transforming the <span className="text-indigo-600">Skill Ecosystem</span>
              </motion.h1>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-xl text-gray-500 mb-10 leading-relaxed"
              >
                Fair, adaptive, and personalized evaluation methods powered by Java and AI. 
                Breaking barriers for every learner, everywhere.
              </motion.p>
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 }}
                className="flex flex-col sm:flex-row items-center justify-center gap-4"
              >
                <button
                  onClick={startAssessment}
                  className="w-full sm:w-auto px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 flex items-center justify-center gap-2 group"
                >
                  Start Java Assessment
                  <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
                <button className="w-full sm:w-auto px-8 py-4 bg-white text-gray-700 border border-gray-200 rounded-2xl font-bold text-lg hover:bg-gray-50 transition-all">
                  Explore Ecosystem
                </button>
              </motion.div>
            </div>

            {/* Features Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <FeatureCard
                icon={Accessibility}
                title="Inclusive Design"
                description="Accessibility features like TTS, STT, and multilingual support integrated into the core."
                color="bg-amber-500"
              />
              <FeatureCard
                icon={RefreshCw}
                title="Adaptive Testing"
                description="Real-time difficulty adjustment based on learner performance for optimal challenge."
                color="bg-emerald-500"
              />
              <FeatureCard
                icon={ShieldCheck}
                title="Secure & Scalable"
                description="Built with Java's robust security features, ensuring data privacy and trust."
                color="bg-blue-500"
              />
              <FeatureCard
                icon={LayoutDashboard}
                title="Skill Analysis"
                description="AI algorithms detect patterns to provide deep insights into individual learning styles."
                color="bg-indigo-500"
              />
            </div>

            {/* Java Focus Section */}
            <div className="bg-white rounded-[2.5rem] border border-gray-100 p-8 md:p-16 shadow-sm flex flex-col lg:flex-row items-center gap-12">
              <div className="flex-1 space-y-6">
                <div className="w-16 h-16 bg-red-50 rounded-2xl flex items-center justify-center">
                  <Code className="w-8 h-8 text-red-600" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">Java-Oriented Perspective</h2>
                <p className="text-gray-500 leading-relaxed">
                  Leveraging Java's platform independence and robust frameworks like Spring Boot to build 
                  scalable assessment systems. Our platform ensures that enterprise-grade security 
                  meets cutting-edge AI capabilities.
                </p>
                <div className="flex flex-wrap gap-3">
                  {['Spring Boot', 'Encryption', 'Secure APIs', 'Scalability'].map(tag => (
                    <span key={tag} className="px-4 py-2 bg-gray-50 text-gray-600 rounded-full text-sm font-medium">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex-1 w-full max-w-md bg-gray-900 rounded-3xl p-8 text-indigo-400 font-mono text-sm shadow-2xl">
                <div className="flex gap-2 mb-6">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <div className="w-3 h-3 rounded-full bg-amber-500" />
                  <div className="w-3 h-3 rounded-full bg-emerald-500" />
                </div>
                <pre className="overflow-x-auto">
                  <code>{`@RestController
@RequestMapping("/api/assessment")
public class AdaptiveController {

  @PostMapping("/next")
  public ResponseEntity<Question> getNext(
    @RequestBody Performance history
  ) {
    // AI-Driven Logic here
    return ResponseEntity.ok(
      aiService.generate(history)
    );
  }
}`}</code>
                </pre>
              </div>
            </div>
          </div>
        )}

        {view === 'quiz' && (
          <AdaptiveQuiz onComplete={handleComplete} />
        )}

        {view === 'results' && results && (
          <ResultsView {...results} />
        )}
      </main>

      <footer className="bg-white border-t border-gray-100 py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-gray-400 text-sm">
            © 2026 InclusiAssess. Built with Java, React, and Google Gemini AI.
          </p>
        </div>
      </footer>
    </div>
  );
}
